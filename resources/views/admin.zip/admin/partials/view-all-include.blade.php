 <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
    <div class="form-group breadcrum-right">
        <div class="dropdown">
            <a class="btn-icon btn btn-primary" href="{{route($route)}}" ><i class="feather icon-list">View All</i></a>
        </div>
    </div>
</div>