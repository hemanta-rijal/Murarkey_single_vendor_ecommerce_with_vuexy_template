    <!-- Map Section Begin -->
    <div class="map spad">

            <div class="map-inner">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3533.3318668077395!2d85.3218043149497!3d27.676136033469994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb1995401331c1%3A0x954710647720c857!2sMurarkey%20(Unlock%20your%20beauty)!5e0!3m2!1sen!2snp!4v1624032973874!5m2!1sen!2snp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

            </div>

    </div>
    <!-- Map Section Begin -->