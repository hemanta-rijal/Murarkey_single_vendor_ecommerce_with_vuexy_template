@extends('frontend.layouts.app')
@section('meta')
    
@endsection
@section('body')
@include('frontend.partials.parlorListing')
@endsection


